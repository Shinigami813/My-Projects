<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body, html {
            height: 100%;
            font-family: 'Poppins', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            background-color: #141e30;
            color: white;
        }
        /* Background particle effect */
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #667eea, #764ba2, #ff6e7f, #bfe9ff);
            z-index: -1;
        }
        /* Animated background gradient */
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        body {
            background-size: 400% 400%;
            animation: gradientAnimation 20s ease infinite;
        }
        /* Shape of welcome portion */
        .welcome-container {
            text-align: center;
            z-index: 2;
            animation: fadeIn 2s ease-out;
            padding: 40px;
            border-radius: 50px; /* Gives it a rounded rectangular shape */
            background: rgba(0, 0, 0, 0.6); /* Semi-transparent black background */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
            width: 80%; /* Adjust width as per your preference */
            max-width: 500px; /* Decreased max-width to prevent overflow */
            padding: 30px 20px; /* Reduced padding for better spacing */
        }
        h1 {
            font-size: 3em; /* Reduced font size */
            margin-bottom: 10px;
            letter-spacing: 3px;
            animation: fadeInTitle 2s ease-out;
        }
        p {
            font-size: 1.5em;
            margin-bottom: 40px;
        }
        /* Button container */
        .cta-buttons {
            display: flex;
            justify-content: center;
            gap: 30px;
        }
        .cta-buttons a {
            text-decoration: none;
            color: white;
            padding: 20px 40px;
            font-size: 1.2em;
            border-radius: 50px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            transition: all 0.4s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        /* Button background effect */
        .cta-buttons a::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background: rgba(255, 255, 255, 0.2);
            transition: all 0.6s ease;
            transform: translate(-50%, -50%) rotate(45deg);
            z-index: -1;
            opacity: 0;
        }
        /* Button hover ripple effect */
        .cta-buttons a:hover::before {
            width: 110%;
            height: 110%;
            opacity: 1;
        }
        .cta-buttons a:hover {
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
            border: 2px solid white;
            transform: translateY(-5px);
        }
        /* Glow animation */
        @keyframes glow {
            0% { box-shadow: 0 0 10px #fff, 0 0 20px #ff6e7f, 0 0 30px #ff6e7f; }
            50% { box-shadow: 0 0 20px #fff, 0 0 40px #667eea, 0 0 60px #ff6e7f; }
            100% { box-shadow: 0 0 10px #fff, 0 0 20px #ff6e7f, 0 0 30px #ff6e7f; }
        }
        .cta-buttons a:hover {
            animation: glow 1.5s infinite alternate;
        }
        /* Fade-in animation for elements */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeInTitle {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* Optional floating animation for buttons */
        @keyframes float {
            0% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0); }
        }
        .cta-buttons a {
            animation: float 4s ease-in-out infinite;
        }
        .loader-container {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 10;
            justify-content: center;
            align-items: center;
        }
        .loader {
            border: 12px solid #f3f3f3;
            border-top: 12px solid #764ba2;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

    <!-- Particle effect using an external library -->
    <div id="particles-js"></div>

    <div class="welcome-container">
        <h1>Welcome</h1>
        <p>Online Attendance System</p>
        <div class="cta-buttons">
        <a href="#" onclick="showLoader()">START</a>
            <!--<a href="register.html">Register</a>-->
        </div>
    </div>
    <div class="loader-container" id="loaderContainer">
        <div class="loader"></div>
    </div>

    <!-- Include the particles.js library (add this to your project or via CDN) -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 80,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#ffffff"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    }
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#ffffff",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "retina_detect": true
        });
        function showLoader() {
            // Show the loader
            document.getElementById("loaderContainer").style.display = "flex";
            
            // Simulate a login process with a timeout (e.g., for an AJAX request)
            setTimeout(function() {
                // Redirect to the login page or hide the loader once the process is done
                window.location.href = "login.php";  // You can replace this with your actual login logic
            }, 3000);  // Simulate 2 seconds loading time
        }
    </script>
</body>
</html>
